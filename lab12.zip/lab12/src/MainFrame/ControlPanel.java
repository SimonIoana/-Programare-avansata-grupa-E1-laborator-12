package MainFrame;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import MainFrame.DesignPanel;

public class ControlPanel extends JPanel{

    DesignPanel control;
    public ControlPanel()
    {
        super("My Frame");
        init();
    }

    private void init()
    {
        JFrame frame = new JFrame("Flow Layout");
        JButton button;
        button = new JButton("Swing component");
        frame.add(button);
        frame.setLayout(new FlowLayout());
        frame.setSize(300,300);
        frame.setVisible(true);
        button.setSize(200, 100);
        control = new DesignPanel(this);
        control.button.addActionListener(actionListener);

    }

    ActionListener actionListener = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == control.button) {
                try {
                    create();
                } catch (IOException e1) {
                    System.out.println(" ");
                }
        }
}
    };

    private void create() throws IOException{
            control.addComponents();
    }


}

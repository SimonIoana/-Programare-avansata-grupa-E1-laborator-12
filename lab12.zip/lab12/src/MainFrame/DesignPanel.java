package MainFrame;

import javax.swing.JButton;
import javax.swing.*;
import java.awt.*;

public class DesignPanel extends JPanel{
    public AbstractButton button;
    JTextField component;
    private void addComponents(){
       add("JButon", BorderLayout.SOUTH);
       add("JPanel", BorderLayout.NORTH);
        add("JLabel", BorderLayout.WEST);
        component = new JTextField(30);
    }



}


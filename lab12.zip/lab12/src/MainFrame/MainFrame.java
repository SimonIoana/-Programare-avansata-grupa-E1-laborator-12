package MainFrame;

import javax.swing.*;

public class MainFrame extends JFrame {

        public static void main(String[] args) {

        ControlPanel frame = new ControlPanel();
        DesignPanel frame = new DesignPanel();

    }
}
